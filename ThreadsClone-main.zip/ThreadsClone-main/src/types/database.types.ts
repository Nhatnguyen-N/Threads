Need to install the following packages:
supabase@2.22.12
Ok to proceed? (y) 
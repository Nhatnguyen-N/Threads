import { Text } from 'react-native';

export default function Search() {
  return <Text>Search</Text>;
}
